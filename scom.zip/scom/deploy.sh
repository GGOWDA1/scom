#!/bin/bash

# Define the namespace
namespace="voting-app"

# Create namespace if it doesn't exist
kubectl create namespace $namespace --dry-run=client -o yaml | kubectl apply -f -

# Deploy the voting app in the specified namespace
kubectl apply -f k8/voting-app-deployment.yaml --namespace=$namespace
